import HeaderComponent from "../../components/HeaderComponent";
import SideNavbarComponent from "../../components/SideNavbarComponent";

export default function IssueListPage() {
  return (
    <div>
      <HeaderComponent />
      <SideNavbarComponent />
    </div>
  );
}
