import React from "react";
import Link from "next/link";
import Image from "next/image";
import HeaderComponent from "../components/HeaderComponent";
import SideNavbarComponent from "../components/SideNavbarComponent";
import { useRouter } from "next/router";
import Data from "../mock.json";
import HighPriorityComponent from "../components/HighPriorityComponent";
import DashboardIssueComponent from "../components/DashboardIssueComponent";
import RecentIssueComponent from "../components/RecentUpdatedComponent";
import styled from "styled-components";

export default function Home() {
  const router = useRouter();

  const highPriorityIssues = Data.issues.filter(
    (issue) => issue.priority === "High"
  );
  const recentUpdatedIssues = Data.issues.filter(
    (issue) =>
      new Date(Date.parse(issue.updated)).getTime() >
      new Date(Date.parse(issue.created)).getTime()
  );

  const n = 4;

  const FirstFourIssues = Data.issues.slice(0, n);

  const backgroundColor = "#6e00ff";
  const Color = "white";

  const ContainerDiv = styled.div`
    margin: 0;
    padding: 0;
    display: grid;
    grid-template-columns: 15% auto;
    grid-template-rows: 4rem auto;
    grid-template-areas:
      "hd hd"
      "navbar main";
  `;
  const HeaderDiv = styled.div`
    grid-area: hd;
    position: fixed;
    width: 100%;
  `;
  const NavbarDiv = styled.div`
    grid-area: navbar;

    height: 100%;
  `;
  const Main = styled.main`
    grid-area: main;
    padding: 15px;
    background: #f4f4f5;
    display: grid;
    grid-template-rows: 60px auto;
    grid-row-gap: 1em;
    height: 100%;
  `;

  const MainHeader = styled.div`
    padding: 5px;
  `;

  const MainContent = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: start;
    padding: 0px;
    gap: 20px;
  `;
  const DashboardDiv = styled.div`
    padding: 0px 60px 0px 10px; ;
  `;
  const Img = styled.img`
    width: 100%;
    height: 100%;
  `;
  const BottomContent = styled.div`
    padding: 10px 60px 10px 10px;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 15px;
    width: 100%;
  `;
  const Card = styled.div`
    background: #ffffff;
    box-shadow: 3px 3px 3px 3px rgba(0, 0, 0, 0.1);
    display: grid;
    grid-template-rows: 5% 87% 5%;
    gap: 5px;
    height: 600px;
  `;
  const H3 = styled.h3`
    padding-left: 20px;
  `;

  const CardContent = styled.div`
    display: grid;
    grid-template-rows: repeat(3, 1fr);
  `;
  const ContentLi = styled.li`
    margin-left: -40px;

    list-style-type: none;

    &:first-of-type {
      border-top-style: ridge;
      border-width: thin;
    }
    border-bottom-style: ridge;
    border-width: thin;
  `;

  const FooterDiv = styled.div`
    padding: 5px 20px 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 1em;
    color: blue;
  `;

  return (
    <ContainerDiv>
      <HeaderDiv>
        <HeaderComponent
          backgroundColor={backgroundColor}
          Color={Color}
          path={router.pathname}
        />
      </HeaderDiv>
      <NavbarDiv>
        <SideNavbarComponent />
      </NavbarDiv>

      <Main>
        <MainHeader className="main-header">
          <h2>Dashboard</h2>
        </MainHeader>
        <MainContent className="main-content">
          <DashboardDiv className="dashboard-graph">
            <Img
              src="/graph.png"
              alt="dashboard-graph"
              className="dashboardLogo"
            />
          </DashboardDiv>
          <BottomContent className="bottom-content">
            <Card className="high-priority-card">
              <H3>High Priority</H3>
              <CardContent>
                <ul>
                  {highPriorityIssues.map((issue) => (
                    <ContentLi>
                      <HighPriorityComponent issue={issue} />
                    </ContentLi>
                  ))}
                </ul>
              </CardContent>

              <FooterDiv className="card-footer">
                <div></div>
                <a href="#">View All</a>
              </FooterDiv>
            </Card>

            <Card className="recent-issue-card">
              <H3>Recently updated issue</H3>
              <CardContent>
                <ul>
                  {recentUpdatedIssues.map((issue) => (
                    <ContentLi>
                      <RecentIssueComponent issue={issue} />
                    </ContentLi>
                  ))}
                </ul>
              </CardContent>

              <FooterDiv className="card-footer">
                <div></div>
                <a href="#">View All</a>
              </FooterDiv>
            </Card>

            <Card className="all-issue-card">
              <H3>All Issue</H3>
              <CardContent>
                <ul>
                  {FirstFourIssues.map((issue) => (
                    <ContentLi>
                      <DashboardIssueComponent issue={issue} />
                    </ContentLi>
                  ))}
                </ul>
              </CardContent>

              <FooterDiv className="card-footer">
                <div></div>
                <a href="#">View All</a>
              </FooterDiv>
            </Card>
          </BottomContent>
        </MainContent>
      </Main>
    </ContainerDiv>
  );
}
