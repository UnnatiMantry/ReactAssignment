import MOCK from "../../mock.json";

export default (req, res) => {
  res.status(200).json(MOCK.issues)
}