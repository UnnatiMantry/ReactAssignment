import styled, { ThemeProvider, css } from "styled-components";

const theme = {
  font: "Open-sans",
};

const Header = styled.header`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #ffffff;
  padding: 10px 20px 0px 20px;
`;
const MidDiv = styled.div`
  margin-left: -50%;
  display: flex;
`;
const FirstDiv = styled.div`
  height: 60%;
`;
const Input = styled.input`
  height: 30px;
  width: 100%;
  font-size: 16px;
  background: #ffffff;
  border: none;
  display: block;
  outline: none;
  padding: 10px;
  ::placeholder {
    padding-left: 20px;
    color: black;
    opacity: 1;
  }
`;

function HeaderComponent() {
  return (
    <ThemeProvider theme={theme}>
      <Header>
        <FirstDiv>
          <img src="/logo.svg" alt="" />
        </FirstDiv>
        <MidDiv>
          <img
            src="/icons-icon_search.svg"
            alt="Search_logo"
            style={{
              margin: "0px -25px 0px 0px",
              zIndex: "1",
            }}
          />
          <Input
            type="text"
            name="searchbar"
            placeholder="search..."
            size="30"
          />
        </MidDiv>
        <div>
          <img src="/user_2.svg" alt="" />
        </div>
      </Header>
    </ThemeProvider>
  );
}
export default HeaderComponent;
