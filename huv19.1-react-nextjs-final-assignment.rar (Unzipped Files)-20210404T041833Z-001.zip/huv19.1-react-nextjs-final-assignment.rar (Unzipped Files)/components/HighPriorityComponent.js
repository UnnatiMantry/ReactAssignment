import styled from "styled-components";

const ContentDiv = styled.div`
  display: grid;
  grid-template-rows: 30% 70%;
`;
const ContentHeaderDiv = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #ffffff;
  padding: 0px 20px 0px 20px;
`;
const Titleh4 = styled.h4`
  font-size: 1em;
`;
const DateP = styled.p`
  font-size: 0.6em;
`;
const DescriptionP = styled.p`
  padding: 0px 20px 0px 20px;
  font-size: 0.8em;
`;

function HighPriorityComponent(props) {
  return (
    <ContentDiv>
      <ContentHeaderDiv>
        <Titleh4>{props.issue.title}</Titleh4>
        <DateP>{props.issue.created}</DateP>
      </ContentHeaderDiv>
      <DescriptionP>{props.issue.description}</DescriptionP>
    </ContentDiv>
  );
}
export default HighPriorityComponent;
