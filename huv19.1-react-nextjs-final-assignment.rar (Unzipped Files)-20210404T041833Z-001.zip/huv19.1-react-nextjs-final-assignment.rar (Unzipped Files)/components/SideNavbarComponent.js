import Link from "next/link";
// import Image from "next/image";
import styled, { ThemeProvider, css } from "styled-components";

const Div = styled.div`
  background: #1d1f37;
  padding: 30px 30px 40px 30px;
  height: 100%;
`;
const Ul = styled.ul`
  display: flex;
  flex-direction: column;
  position: relative;
  height: 100%;
  margin: 0;
  padding: 30px 0;
`;
const Li = styled.li`
  margin-bottom: 30px;
  padding: 12px 20px;
  list-style: none;
  width: 100%;
  border-radius: 5px;
  align-items: center;
  display: flex;
  position: relative;
  :hover {
    background: #6e00ff;
  }
  :hover A {
    color: white;
  }
`;

const A = styled.a`
  position: relative;
  color: #494d75;
  font-size: 1.1em;
`;
const Image = styled.img`
  width: 20px;
  height: 20px;
`;

function SideNavbarComponent(props) {
  return (
    <Div>
      <Ul>
        <Li background={props.backgroundColor}>
          <Image src="/Dashboard_dark.svg" alt="dashboard_logo" />
          &nbsp;&nbsp; &nbsp;
          <A href="../" color={props.color}>
            Dashboard
          </A>
        </Li>
        <Li background={props.backgroundColor}>
          <Image src="/Issues_dark.svg" alt="issues_logo" />
          &nbsp; &nbsp; &nbsp;
          <A href="../issues" color={props.color}>
            Issues
          </A>
        </Li>
        <Li background={props.backgroundColor}>
          <Image src="/Create_dark.svg" alt="ireateissue_logo" />
          &nbsp;&nbsp; &nbsp;
          <A href="../createissue" color={props.color}>
            Create
          </A>
        </Li>
      </Ul>
    </Div>
    //  <Link href="../">
    //         <img src="../asset/Dashboard_dark.svg" alt="dashboard_logo" />
    //         Dashboard
    //       </Link>
  );
}
export default SideNavbarComponent;
