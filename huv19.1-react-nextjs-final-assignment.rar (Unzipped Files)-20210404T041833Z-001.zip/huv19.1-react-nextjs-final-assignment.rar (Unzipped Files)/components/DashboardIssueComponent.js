import styled from "styled-components";

const ContentDiv = styled.div``;
const TopDiv = styled.div`
  padding: 5px 15px 15px 15px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const ProfileDiv = styled.div`
  display: flex;
  justify-content: flex-start;
  gap: 10px;
  align-items: center;
  font-size: 0.8em;
  padding: 5px 0px 0px 20px;
`;

const SplitDiv = styled.div`
  display: flex;
  flex-direction: column;
`;
const AssigneSpan = styled.span`
  font-size: 1.5em;
`;
const DesginationSpan = styled.span`
  font-size: 1em;
`;
const BottomDiv = styled.div`
  padding: 5px 20px 0px 20px;
`;
const PercentageBarLightDiv = styled.div`
  height: 8px;
  background: lightgray;
  border-radius: 5px;
`;
const PercentageBarDarkDiv = styled.div`
  height: 8px;
  width: ${(props) => (props.color >= 5 ? "60%" : "40%")};
  background: ${(props) => (props.color >= 5 ? "purple" : "yellow")};
  border-radius: 5px;
`;
const IssueDetailsDiv = styled.div`
  display: flex;
  justify-content: space-between;
  gap: 10px;
  align-items: center;
  padding: 0px 10px 0px 10px;
  > p {
    font-size: 0.8em;
  }
`;
const Img = styled.img``;
function DashboardIssueComponent(props) {
  return (
    <ContentDiv>
      <TopDiv>
        <ProfileDiv>
          <Img src="/user_2.svg" alt="Assigne_Photo" />
          <SplitDiv>
            <AssigneSpan>{props.issue.assignee}</AssigneSpan>
            <DesginationSpan>{props.issue.assignee_desig}</DesginationSpan>
          </SplitDiv>
        </ProfileDiv>
      </TopDiv>
      <BottomDiv>
        <PercentageBarLightDiv>
          <PercentageBarDarkDiv
            color={props.issue.story_points}
          ></PercentageBarDarkDiv>
        </PercentageBarLightDiv>
        <IssueDetailsDiv>
          <p>
            High Priority Issue:&nbsp;
            <span>{props.issue.story_points}</span>
          </p>
          <p>
            Total Issue:&nbsp;
            <span>{props.issue.story_points}</span>
          </p>
        </IssueDetailsDiv>
      </BottomDiv>
    </ContentDiv>
  );
}
export default DashboardIssueComponent;
